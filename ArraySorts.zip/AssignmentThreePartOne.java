
//import needed javaClasses 
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.sound.sampled.Line;

public class AssignmentThreePartOne {
    public static void main(String[] args) {
        /// create new itemLists
        ItemList shoppingList = new ItemList("shoppingList");
        ItemList purchaseList = new ItemList("purchaseList");

        String filename = "a3q1in.txt"; // filename that stores the itemList given
        String[] list; // array of strings called list
        
        //create a try_catch resource 
        try {

            FileReader file = new FileReader(filename); // file reader of the file
            BufferedReader reader = new BufferedReader(file); // bufferReader for the file
            String line = ""; // create an empty string
            ArrayList<ItemList> itemLists = new ArrayList<ItemList>(); // creare a new array of itemLists
            itemLists.add(shoppingList);// add shoppingLists to the list of itemLists
            itemLists.add(purchaseList); // add purchaseLists to the list of itemLists
            // Loop through the line string while its not null
            while ((line = reader.readLine()) != null) {
                list = line.split(","); // create an array by splitting through
                if (list[0].equalsIgnoreCase("need")) { // if the first entry of each line is need
                    shoppingList.ItemListIncrease(list[2], Integer.parseInt(list[1])); // increase or add to the  shopping list
                }
                if (list[0].equalsIgnoreCase("buy")) { // if the first entry of each line is buy
                    shoppingList.ItemListDecrease(list[2], Integer.parseInt(list[1])); // decrease or remove that item from the shopping list
                    purchaseList.ItemListIncrease(list[2], Integer.parseInt(list[1])); // increase or add to the  purchase list
                }
                if (list[0].trim().equalsIgnoreCase("list")) { // if the first entry of each line is list after trimming 
                    //loop through the aray list of itemList 
                    for (int i = 0; i < itemLists.size(); i++) {
                        System.out.println("========================="); //print a barrier 
                        System.out.println(itemLists.get(i).getItemListName()); //then print the name of each index in the itemList  
                        System.out.println(itemLists.get(i)); //then print  each index in the itemList  
                    }
                }

            }

        } catch (IOException e) {
            System.out.println("File not found: " + filename); //print exception 
        } catch (Exception e) {
            e.printStackTrace(); //print stack trace for the exception 
        }
    }
}
