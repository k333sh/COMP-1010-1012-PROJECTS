public class challenge {
    public static void main(String[] args) {
        int a = 0;
        int z = flip(a);
        System.out.println(z);
    }

    public static int flip(int a) {
      return  (int) Math.pow(0.0, a)  ;
    }
}
