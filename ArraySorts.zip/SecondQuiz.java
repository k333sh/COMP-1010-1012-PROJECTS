import java.util.ArrayList;

public class SecondQuiz {
    public static void main(String[] args) {

        ArrayList<String> List = new ArrayList<String>();
        ArrayList<Integer> practice = new ArrayList<Integer>() ;

        practice.add(5);
        practice.add(7);
        practice.add(9);
         ArrayList<Integer> Z = (ArrayList<Integer>) practice.clone() ;
         Z.add(11);

      
        System.out.println(Z);
    }
}
