import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class practiceTest {
    public static void main(String[] args) {
        String a = "ignore,1,2,-8,X,100,200,Y,hello world,65535";

    }

    public int name(String a) {
        int index = 0;

        String[] array = a.split(",");
       

            Scanner reader = new Scanner(a);
            String c =  reader.nextLine();
            
            int sum = 0;
             boolean z = reader.hasNextInt();
            do {
                
                sum += Integer.parseInt(c);
                
                }
             while (z == true);
             if(z== false){
                return sum ;
             }

         return index ;
         
    
        }
    }

