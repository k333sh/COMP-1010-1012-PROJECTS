public class testRun {
    
        public static void main(String[] args) {
            ItemList shoppingList = new ItemList();
            ItemList purchaseList = new ItemList();
        
            String filename = "data.txt";
            String[] list;
            ArrayList<String> arrayList = new ArrayList<String>();
            try {
                FileReader file = new FileReader(filename);
                BufferedReader reader = new BufferedReader(file);
                String line = "";
                while ((line = reader.readLine()) != null) {
                    list = line.split(",");
                    if (list[0].equalsIgnoreCase("need")) {
                        shoppingList.increase(list[2], Integer.parseInt(list[1]));
                    } else if (list[0].equalsIgnoreCase("buy")) {
                        if (shoppingList.contains(list[2])) {
                            int diff = shoppingList.getQuantity(list[2]) - Integer.parseInt(list[1]);
                            if (diff >= 0) {
                                shoppingList.decrease(list[2], Integer.parseInt(list[1]));
                                purchaseList.increase(list[2], Integer.parseInt(list[1]));
                            } else {
                                shoppingList.decrease(list[2], shoppingList.getQuantity(list[2]));
                                purchaseList.increase(list[2], shoppingList.getQuantity(list[2]));
                                System.out.println(":Warning: decreasing quantity of " + list[2] + " by " + (-diff) + " but only " + shoppingList.getQuantity(list[2]) + " in list");
                            }
                        } else {
                            System.out.println(":Warning: " + list[2] + " not in list");
                            purchaseList.increase(list[2], Integer.parseInt(list[1]));
                        }
                    } else if (list[0].equalsIgnoreCase("list")) {
                        System.out.println("==============");
                        System.out.println("Shopping List:");
                        System.out.println(shoppingList);
                        System.out.println("Purchase List:");
                        System.out.println(purchaseList);
                        System.out.println("==============");
                    }
                }
                reader.close();
            } catch (IOException e) {
                System.out.println("File not found: " + filename);
            }
        }
        
    }

